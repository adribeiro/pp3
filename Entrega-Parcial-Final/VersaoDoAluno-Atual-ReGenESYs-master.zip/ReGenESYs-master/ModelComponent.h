/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Element.h
 * Author: rafael.luiz.cancian
 *
 * Created on 21 de Junho de 2018, 15:56
 */

#ifndef MODELCOMPONENT_H
#define MODELCOMPONENT_H

#include <string>
#include <list>

#include "Plugin.h"
#include "List.h"
#include "Entity.h"
#include "ModelElement.h"
#include "ConnectionManager.h"

class Model;

/**
 * A component of the model is a block that represents a specific behavior to be simulated. The behavior is triggered when an entity arrives at the component, which corresponds to the occurrence of an event. A simulation model corresponds to a set of interconnected components to form the process by which the entity is submitted.
 * @param model The model this component belongs to
 */
class ModelComponent : public ModelElement {
public:
    ModelComponent(Model* model, std::string componentTypename);
    ModelComponent(const ModelComponent& orig);
    virtual ~ModelComponent();
public:
    virtual std::string show();
public:
    ConnectionManager* getNextComponents() const; ///< Returns a list of components directly connected to the output. Usually the components have a single output, but they may have none (such as Dispose) or more than one (as Decide). In addition to the component, NextComponents specifies the inputNumber of the next component where the entity will be sent to. Ussually the components have a single input, but they may have none (such as Create) or more than one (as Match).
public:
    static void Execute(Entity* entity, ModelComponent* component, unsigned int inputNumber); ///< This method triggers the simulation of the behavior of the component. It is invoked when an event (corresponding to this component) is taken from the list of future events or when an entity arrives at this component by connection.
    static void InitBetweenReplications(ModelComponent* component);
    static bool Check(ModelComponent* component);
    static ModelComponent* LoadInstance(Model* model, std::map<std::string, std::string>* fields);
    static std::map<std::string, std::string>* SaveInstance(ModelComponent* component);
private:
    ConnectionManager* _nextComponents = new ConnectionManager();
    List<Util::identification>* _tempLoadNextComponentsIDs; // initialize only when loading 
protected:
    virtual void _execute(Entity* entity) = 0;
    virtual void _initBetweenReplications() = 0;

protected:
    virtual std::map<std::string, std::string>* _saveInstance();
    virtual bool _loadInstance(std::map<std::string, std::string>* fields);
    //virtual std::list<std::map<std::string,std::string>*>* _saveInstance(std::string type);

protected:
    Model* _model;
};

#endif /* MODELCOMPONENT_H */

