/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ElementManager_if.h
 * Author: rafael.luiz.cancian
 *
 * Created on 22 de Novembro de 2018, 01:06
 */

#ifndef ELEMENTMANAGER_IF_H
#define ELEMENTMANAGER_IF_H

class ElementManager_if {
public:
    ElementManager_if();
    ElementManager_if(const ElementManager_if& orig);
    virtual ~ElementManager_if();
private:

};

#endif /* ELEMENTMANAGER_IF_H */

