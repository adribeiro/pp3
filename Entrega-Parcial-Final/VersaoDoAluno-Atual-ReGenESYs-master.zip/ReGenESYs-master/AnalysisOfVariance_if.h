/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AnalysisOfVariance_if.h
 * Author: rlcancian
 *
 * Created on 21 de Junho de 2019, 16:08
 */

#ifndef ANALYSISOFVARIANCE_IF_H
#define ANALYSISOFVARIANCE_IF_H

class AnalysisOfVariance_if {
public:
    virtual void setCollector() = 0;
};

#endif /* ANALYSISOFVARIANCE_IF_H */

