/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ScenarioExperiment_if.h
 * Author: rafael.luiz.cancian
 *
 * Created on 10 de Outubro de 2018, 14:52
 */

#ifndef SCENARIOEXPERIMENT_IF_H
#define SCENARIOEXPERIMENT_IF_H

class ScenarioExperiment_if {
};

#endif /* SCENARIOEXPERIMENT_IF_H */

