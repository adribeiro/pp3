/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   DefaultTraceAndEventHandlers.h
 * Author: rlcancian
 *
 * Created on 3 de Setembro de 2019, 16:12
 */

#ifndef DEFAULTTRACEANDEVENTHANDLERS_H
#define DEFAULTTRACEANDEVENTHANDLERS_H

/*
#include "TraceManager.h"
#include "OnEventManager.h"
#include <iostream>

// default Trace Handlers
void traceHandlerFunction(TraceEvent e) {
    std::cout << e.getText() << std::endl;
}

void traceSimulationHandlerFunction(TraceSimulationEvent e) {
    std::cout << e.getText() << std::endl;
}

void onSimulationStartHandlerFunction(SimulationEvent* re) {
    //std::cout << "(Handler) Simulation is starting" << std::endl;
}


// default Event Handlers
void onReplicationStartHandlerFunction(SimulationEvent* re) {
   // std::cout << "(Handler) Replication " << re->getReplicationNumber() << " starting." << std::endl;
}

void onProcessEventHandlerFunction(SimulationEvent* re) {
    //std::cout << "(Handler) Processing event " << re->getEventProcessed()->show() << std::endl;
}

void onReplicationEndHandlerFunction(SimulationEvent* re) {
    //std::cout << "(Handler) Replication " << re->getReplicationNumber() << " ending." << std::endl;
}

void onEntityRemoveHandlerFunction(SimulationEvent* re) {
    //std::cout << "(Handler) Entity " << re->getEventProcessed()->getEntity() << " was removed." << std::endl;
}
*/
#endif /* DEFAULTTRACEANDEVENTHANDLERS_H */

