/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FourthExampleOfSimulation.h
 * Author: rlcancian
 *
 * Created on 24 de Setembro de 2019, 20:56
 */

#ifndef FOURTHEXAMPLEOFSIMULATION_H
#define FOURTHEXAMPLEOFSIMULATION_H

#include "BaseConsoleGenesysApplication.h"

class FourthExampleOfSimulation : public BaseConsoleGenesysApplication {
public:
    FourthExampleOfSimulation();
public:
    virtual int main(int argc, char** argv);
};

#endif /* FOURTHEXAMPLEOFSIMULATION_H */

