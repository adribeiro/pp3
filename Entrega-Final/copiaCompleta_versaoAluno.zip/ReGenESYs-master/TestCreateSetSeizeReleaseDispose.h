/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TestCreateSetSeizeReleaseDispose.h
 * Author: ad
 *
 * Created on 21 de outubro de 2019, 14:09
 */

#ifndef TESTCREATESETSEIZERELEASEDISPOSE_H
#define TESTCREATESETSEIZERELEASEDISPOSE_H

#include "BaseConsoleGenesysApplication.h"

class TestCreateSetSeizeReleaseDispose: public BaseConsoleGenesysApplication{
public:
    TestCreateSetSeizeReleaseDispose();
    TestCreateSetSeizeReleaseDispose(const TestCreateSetSeizeReleaseDispose& orig);
    virtual ~TestCreateSetSeizeReleaseDispose();
    virtual int main(int argc, char** argv);
private:

};

#endif /* TESTCREATESETSEIZERELEASEDISPOSE_H */

